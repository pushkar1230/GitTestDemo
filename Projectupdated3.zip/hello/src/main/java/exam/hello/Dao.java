package exam.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
@Service
public class Dao {
	private Repo r;
	private Repo2 r2;
	private Repo3 r3;

	Dao(){
		System.out.println("dao layer object created");
		//this.r=r;
		//this.r2=r2;
	}

	@Autowired
	public void setR(Repo r) {
		this.r=r;
	}
	@Autowired
	public void setR2(Repo2 r2) {
		this.r2=r2;
	}

	@Autowired
	public void setR3(Repo3 r3) {
		this.r3=r3;
	}

	public void func() {

	}

	public Tester addData(Tester t) {
		// TODO Auto-generated method stub
		System.out.println("in next function hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
		//if(r.existsById(t.getTestername())) {
		Tester t2=	r.save(t);
	//	}else {
		//	r.saveAndFlush(t);
		//}
		System.out.println(t2);
		return t2;
	}

	public Tester chkTester(Tester t) {
		// TODO Auto-generated method stub
		Tester t1=null;
		if(r.existsById(t.getTesterid())) {
			t1=r.getOne(t.getTesterid());
			System.out.println(t1);
			if(t1.getTesterpwd().equals(t.getTesterpwd()))
			return t1;
			else {
				t1=new Tester(0,"","", null, null,null);
			return t1;
			}
		}
		else {
			t1=new Tester(0,"","", null, null,null);
			return t1;
		}}

	public Developer chkDeveloper(Developer d) {
		Developer d1=null;
		if(r2.existsById(d.getDeveloperid())){
			d1=r2.getOne(d.getDeveloperid());
			System.out.println(d1);
			if(d1.getDeveloperpwd().equals(d.getDeveloperpwd()))
			return d1;
			else {
				d1=new Developer(0,"","", null, null,null);
			return d1;
			}
		}
		else {
			d1=new Developer(0,"","", null, null,null);
			return d1;
		}}

	public Developer addDeveloper(Developer d2) {
		// TODO Auto-generated method stub
		Developer  dev;
		dev=r2.save(d2);
		return dev;
	}

	public Tester addTester(Tester t) {
		// TODO Auto-generated method stub
		Tester t2;
	    t2=r.save(t);
		return t2;
	}

	public Bugs addBugs(Bugs b) {
		// TODO Auto-generated method stub
		Bugs b2;
	    b2=r3.saveAndFlush(b);
	    
		return b2;
	}

	public Bugs chkBugs(Bugs b) {
		// TODO Auto-generated method stub
		Bugs b1;
		
		System.out.println(b.getDeveloperid());
		if(r3.existsById(b.getBugid())) {
			System.out.println("in if loop");
			b1=r3.getOne(b.getBugid());
			System.out.println(b1.getDeveloperid());
			System.out.println(b.getDeveloperid());
			
			if(b1.getDeveloperid().equals(b.getDeveloperid())) {
				
				System.out.println("in next if loop");
				return b1;
			}
			else {
				Bugs b2= new Bugs(0, null, null, null, null, null, null, null);
				System.out.println("in inner else loop");
				return b2;
			}
			}
		else {
		System.out.println("in outer else");
			b1= new Bugs(0, null, null, null, null, null, null, null);
		
		}	return b1;
	
	}

	public List<Tester> view_tester_list() {
		// TODO Auto-generated method stub
		List<Tester> tester = r.findAll();
		return tester;
	}

	public List<Developer> view_developer_list() {
		// TODO Auto-generated method stub
		List<Developer> developer = r2.findAll();
		return developer;
	}

	public List<Bugs> getBugsTester(Integer testerid) {
		// TODO Auto-generated method stub
		List<Bugs> b = r3.getBugsTester(testerid);
		return b;
	}

	public List<Bugs> view_bug_list() {
		// TODO Auto-generated method stub
		List<Bugs> bugs = r3.findAll();
		return bugs;
	}

	public List<Bugs> getDeveloperBugs(Integer developerid) {
		// TODO Auto-generated method stub
		List<Bugs> l=r3.getDeveloperBugs(developerid);
		return l;
	}


}
	
