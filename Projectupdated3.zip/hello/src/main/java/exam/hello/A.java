package exam.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

//@RestController
@Controller
public class A {

	private Service1 service;

	
	@Autowired
	public A(Service1 service) {
		System.out.println("servicelayer wired to contoller");
		this.service = service;
		// TODO Auto-generated constructor stub
	}

	@RequestMapping("/")
	public String index(Model model) {
		String name = "aakash";
		model.addAttribute("name", name);
		return "main";
	}

	@GetMapping("/Request")
	public String mainpage(@RequestParam("mainpage") String page) {
		System.out.println("f1 invoked");
		// String name="aakash";
		// m.addAttribute("name", name);
		if (page.equalsIgnoreCase("Admin"))
			return "admin";
		else if (page.equalsIgnoreCase("Main"))
			return "main";
		else if (page.equalsIgnoreCase("Tester"))
			return "demoFile";
		else if (page.equalsIgnoreCase("Developer"))
			return "developer";
		else
			return "developer";
	}

	@RequestMapping(value = "/tester", method = RequestMethod.POST)
	public String testerloginchk(@ModelAttribute Tester t, Model m) {
		System.out.println("tester adding func 111");
		System.out.println(t);
		Tester t1 = service.chkTester(t);

		if (t1.getTesterid() == 0) {
			m.addAttribute("Tester", t1);
			return "demoFile";
		} else {
			m.addAttribute("Tester", t1);
			List<Bugs> b = service.getBugsTester(t1.getTesterid());
			System.out.println("size=" + b.size());
			if (b.size() == 0) {
				m.addAttribute("id", t1.getTesterid());
				return "tester2bugtableEmpty";
			} else {
				m.addAttribute("id", t1.getTesterid());
				m.addAttribute("t", b);
				return "tester2";
			}
		}
	}

	@RequestMapping(value = "/developer", method = RequestMethod.POST)
	public String developerloginchk(@ModelAttribute Developer d, Model m) {
		System.out.println(d);
		Developer d1 = service.chkDeveloper(d);
		List<Bugs> b = service.getDeveloperBugs(d1.getDeveloperid());
		if (d1.getDeveloperid() == 0) {
			m.addAttribute("Developer", d1);
			return "commonfile";
		} else {
			// m.addAttribute(d1);
			System.out.println(b);
			m.addAttribute("k1", b);
			return "developer2";
		}
	}

	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String adminloginchk(@ModelAttribute Admin a, Model m) {
		Admin a1 = service.chkAdmin(a);
		/*
		 * if ((a1.getAdminname().equals("Aakashgarg")) &&
		 * (a1.getAdminpwd().equals("garg12345"))) { m.addAttribute("Admin", a1); return
		 * "admin2";
		 * 
		 * } else { m.addAttribute("Admin", a1); return "admin"; }
		 */
		return "admin2";
		}

	@GetMapping("/viewtableRequest")
	public String view_table_list(@RequestParam("viewtable") String s, Model m) {
		System.out.println(s);
		String page = null;
		if (s.equalsIgnoreCase("tester")) {
			List<Tester> test = service.view_tester_list();
			m.addAttribute("k1", test);
			page = "viewtestertable";
		} else if (s.equalsIgnoreCase("developer")) {
			List<Developer> test = service.view_developer_list();
			m.addAttribute("k1", test);

			page = "viewdevelopertable";
		} else {
			List<Bugs> bug = service.view_Bug_list();
			m.addAttribute("k1", bug);
			page = "viewbugtable";
		}
		return page;
	}

	@GetMapping("/addRequest")
	public String add_developer_tester(@RequestParam("adminpage") String s) {
		System.out.println("f4 invoked");
		if (s.equalsIgnoreCase("developer"))
			return "adddeveloper";
		else
			return "addtester";
	}

	@GetMapping("/backRequest")
	public String admin_bck_request(@RequestParam("adminaddpage") String s) {
		System.out.println("f6 invoked");
		return "admin2";

	}

	@RequestMapping(value = "/adddeveloper", method = RequestMethod.POST)
	public String admin_add_developer(@ModelAttribute Developer d, Model m) {
		// String message="Success";
		System.out.println(d);
		Developer d1 = service.addDeveloper(d);
		Integer i = d1.getDeveloperid();
		if (d1.getDeveloperid() == 0) {
			m.addAttribute("message", i);
			return "dataNotadded";

		} else {
			m.addAttribute("developer", i);

			return "adddeveloper_id";
		}
	}

	@RequestMapping(value = "/addtester", method = RequestMethod.POST)
	public String admin_add_tester(@ModelAttribute Tester t, Model m) {
		System.out.println(t);
		Tester t1 = service.addTester(t);
		System.out.println(t1);
		Integer i = t1.getTesterid();
		System.out.println(i);
		if (t1.getTesterid() == 0) {
			m.addAttribute("tester", i);

			return "dataNotadded";

		} else {
			m.addAttribute("tester", i);

			return "addtester_id";
		}
	}

	@GetMapping("/TesterRequest")
	public String tester_bug_linkpage(@RequestParam("page") String page, Model m) {
		System.out.println("value =" + page);
		String s[] = page.split(" ");

		Integer id = Integer.parseInt(s[0]);
		System.out.println(id);
		String i = s[1];
		System.out.println(i);
		if (i.equals("assign")) {
			List<Developer> l = service.view_developer_list();
			m.addAttribute("id", id);
			m.addAttribute("developer", l);
			return "bugassign";
		} else {
			List<Bugs> b = service.getBugsTester(id);
			if (b.size() == 0) {
				m.addAttribute("id", id);
				return "tester2bugtableEmpty";
			} else {
				m.addAttribute("id", id);
				m.addAttribute("t", b);
				return "tester2";

			}
		}
	}

	@RequestMapping(value = "/AssignDeveloperToSolveBugs", method = RequestMethod.POST)
	public String tester_add_bugs(@ModelAttribute Bugs b, Model m) {
		System.out.println(b);
		Bugs b1 = service.addBugs(b);
		System.out.println(b1.getBugid());
		Integer i = b1.getBugid();
		List<Developer> l = service.view_developer_list();

		m.addAttribute("developer", l);

		m.addAttribute("bugid", i);
		return "bugassign";

	}

	@RequestMapping(value = "/FindBugs", method = RequestMethod.POST)
	public String f3(@ModelAttribute Bugs b, Model m) {
		System.out.println(b);
		Bugs b1 = service.chkBugs(b);
		System.out.println(b1);
		if (b1.getBugid() == 0) {
			m.addAttribute("Bugs", b1);
			return "bugfoundnotassign";
		} else if (b1.getBugid() == 0) {
			m.addAttribute("Bugs", b1);
			return "bugnotfound";
		} else
			m.addAttribute("Bugs", b1);
		return "bugtable";

	}

}