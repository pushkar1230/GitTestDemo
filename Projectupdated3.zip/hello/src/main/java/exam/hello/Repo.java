package exam.hello;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
//import org.springframework.web.bind.annotation.RequestParam;


@Repository
public interface Repo extends JpaRepository<Tester, Integer> {
	
	//Mobile is entity class, Integer is primary key
	// hibernate will never work until you use concept called Primary key.
	
//@Query(" from Employee where empcity =x" )
	//List<Employee> findAllActiveUsers(@RequestParam("x")String x);
		
//@Query("from Employee where ")
}